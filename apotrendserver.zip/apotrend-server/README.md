# ApoTrend Live — Echte Pharma-Daten

Vercel-Projekt mit 3 Serverless-API-Endpunkten + einem Bloomberg-artigen Frontend.

## Echte Datenquellen
| Endpunkt | Quelle | Beschreibung |
|---|---|---|
| `/api/engpass` | BASG / Fallback | AT Engpassdaten |
| `/api/stocks` | Yahoo Finance | Pharma-Aktienkurse live |
| `/api/recalls` | openFDA | US-Medikamenten-Rückrufe |

## Deploy (5 Minuten)

### 1. GitHub-Repo anlegen
Neues Repo z. B. `apotrend-live` auf GitHub erstellen.
Diesen Ordner hochladen (alle Dateien).

### 2. Vercel verbinden
1. https://vercel.com → kostenlos registrieren
2. „Add New Project" → GitHub-Repo `apotrend-live` auswählen
3. Framework: **Other** (kein Framework)
4. Root Directory: `.` (Standard)
5. **Deploy** klicken

Vercel erkennt `vercel.json` und `api/` automatisch.

### 3. Live-URL
Nach ~1 Minute: `https://apotrend-live.vercel.app`
- Frontend: `https://apotrend-live.vercel.app/`
- API-Test: `https://apotrend-live.vercel.app/api/recalls`

## Lokal testen
```bash
npm i -g vercel
vercel dev
# → http://localhost:3000
```

## Hinweise
- Yahoo Finance hat keine offizielle API — fallweise Rate-Limits möglich.
- BASG hat keine öffentliche API; `/api/engpass` versucht die Seite zu parsen, nutzt bei Fehlern Fallback-Daten.
- Alle Daten werden im Browser **nicht gecacht** (`cache: 'no-store'`).
- Automatische Aktualisierung alle **60 Sekunden**.
